const e="https://bnkanwtzusfbsbqthona.supabase.co/functions/v1/generate-primer",t=[{id:"personal-project",name:"Personal Project",description:"Home renovation, event planning, hobby projects",icon:"🏠",currentTask:"Planning a [type of project] — [brief description]. Need to figure out [main challenge], budget for [materials/services], and timeline for [milestone].",keyDecisions:`Budget: [amount]
Timeline: [start date] → [end date]
DIY vs hiring help: [which]
Top priority: [what matters most]`,relevantLinks:`Pinterest / inspiration board
Vendor quotes
Budget spreadsheet`,additionalNotes:"Space constraints: [details]. Preferred aesthetic: [style]. Must finish by [deadline].",tags:["diy","planning","lifestyle"]},{id:"health-wellness",name:"Health & Wellness",description:"Fitness, nutrition, habits, mindfulness",icon:"🧘",currentTask:"Working on [health goal] — [specific target like run 5k / lose X kg / meditate daily]. Current baseline: [starting point]. Struggling with [obstacle].",keyDecisions:`Primary focus: [fitness / nutrition / sleep / stress]
Schedule: [days per week / time of day]
Tracking method: [app / journal / none]
Accountability partner: [yes / no]`,relevantLinks:`Workout plan / app
Meal prep recipes
Progress photos / log`,additionalNotes:"Medical considerations: [any injuries / conditions]. Equipment available: [gym / home / none]. Target habit: [specific daily action].",tags:["fitness","habits","lifestyle"]},{id:"research-essay",name:"Research & Essay",description:"Papers, theses, research projects, literature reviews",icon:"📝",currentTask:"Writing a [paper/thesis/report] on [topic]. Need to cover [key arguments], find sources on [subtopic], and structure it around [thesis statement].",keyDecisions:`Format: [APA / MLA / Chicago / other]
Word count target: [number]
Core sources: [primary references]
Argument structure: [problem → analysis → conclusion / compare & contrast]`,relevantLinks:`Google Scholar / library search
Source PDFs / Zotero library
Outline doc (Notion / Google Docs)`,additionalNotes:"Submission deadline: [date]. Advisor/grader: [name]. Need peer review by [date]. Must include [diagrams / data / appendices].",tags:["academic","writing","research"]},{id:"exam-prep",name:"Exam Preparation",description:"Study plans, flashcards, revision strategies",icon:"📚",currentTask:"Studying for [exam name] on [date]. Topics include [list of subjects]. Currently at [comfort level with material]. Need to focus on [weakest topic].",keyDecisions:`Study method: [Active recall / Pomodoro / Spaced repetition]
Resources: [textbook / lectures / practice exams]
Study schedule: [hours per day / days per week]
Practice tests: [number planned]`,relevantLinks:`Syllabus / exam guide
Flashcards (Anki / Quizlet)
Past papers / mock exams`,additionalNotes:"Target score: [grade / percentile]. Study buddy group: [yes / no]. Exam format: [multiple choice / essay / practical].",tags:["studying","academic","planning"]},{id:"business-strategy",name:"Business Strategy",description:"Business plans, pitches, proposals, go-to-market",icon:"💼",currentTask:"Developing a [business plan / pitch deck / proposal] for [venture]. Key value proposition: [what you offer]. Target market: [customer segment]. Revenue model: [how you make money].",keyDecisions:`Business model: [SaaS / marketplace / service / e-commerce]
Pricing: [per month / per use / tiered]
Funding stage: [bootstrapped / pre-seed / seed]
Go-to-market: [organic / paid / partnerships]`,relevantLinks:`Market research / competitor analysis
Financial projections spreadsheet
Investor / partner list`,additionalNotes:"Launch target: [date]. Break-even goal: [month]. Key risk: [biggest unknown]. Advisory board: [names].",tags:["business","strategy","entrepreneurship"]},{id:"career-job",name:"Career & Job Search",description:"Resumes, interviews, career transitions, networking",icon:"🎯",currentTask:"Applying for [role type] roles in [industry/field]. Currently at [current role]. Target companies: [list]. Biggest gap to fill: [skill or experience needed].",keyDecisions:`Target roles: [job titles]
Priority factors: [salary / culture / growth / location]
Application strategy: [quality over quantity / spray and pray]
Timeline: [start date → offer by date]`,relevantLinks:`Resume / CV (current draft)
Portfolio / GitHub / LinkedIn
Job boards / company career pages`,additionalNotes:"Salary range: [min–max]. Willing to relocate: [yes / no / hybrid]. Need to prep for: [technical / behavioral / case interviews].",tags:["career","growth","business"]},{id:"software-project",name:"Software Project",description:"Features, fixes, architecture, code reviews",icon:"💻",currentTask:"Working on [project name] — [feature / bug / refactor]. Need to implement [specific change], consider trade-offs between [option A] vs [option B], and ensure [quality concern like tests / performance / security].",keyDecisions:`Stack: [language / framework / runtime]
Architecture approach: [pattern / design decision]
Database / storage: [which one]
Deployment target: [platform / environment]`,relevantLinks:`GitHub / repo link
PR / issue link
API docs / spec`,additionalNotes:"Deadline: [date]. Dependencies: [blocking items]. Needs review from: [name(s)]. Risk areas: [complex parts to watch out for].",tags:["dev","code","engineering"]}];export{e as P,t as T};
